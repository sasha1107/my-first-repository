import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Store, Option } from 'pages';

const Router = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<div>Home</div>} />
        <Route path="/store/:storeId" element={<Store />} />
        <Route path="/store/:storeId/menu/:menuId" element={<Option />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Router;
