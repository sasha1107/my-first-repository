import { useParams, useLocation } from 'react-router-dom';
import { MenuList } from 'components';
import { useState, useEffect } from 'react';
import data from 'constants/data.json';

const Store = () => {
  const { storeId } = useParams();
  const storeData = data.find((item) => item.storeId === Number(storeId));
  console.log(useLocation().search, 'useLocation()')
  const [totalAmount, setTotalAmount] = useState(0);
  const [totalPrice, setTotalPrice] = useState(0);

  useEffect(() => {
    // URLSearchParams 객체를 사용하여 쿼리 문자열을 파싱하고 디코딩합니다.
    const searchParams = new URLSearchParams(location.search);
    location.search && console.log('location.search',location.search)
    console.log('searchParams',searchParams)

    // URLSearchParams 객체를 JavaScript 객체로 변환합니다.
    // const params: any = {};
    for (const [key, value] of searchParams) {
      console.log(key, value)
      console.log(decodeURIComponent(value))
      console.log(JSON.parse(atob(value)))
      // params[key] = decodeURIComponent(value);
    }
  }, [location.search]);

  if (!storeData) return null;
  return (
    <>
    <MenuList data={storeData} />
    <button>
      {totalAmount > 0 &&
      <span>
        {totalAmount}
      </span>
      }
      주문하기
      {totalPrice > 0 && 
        <span>
        {(totalPrice).toLocaleString()}원
        </span>
      }
      </button>
    </>
  );
};

export default Store;
