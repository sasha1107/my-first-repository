import { MenuOption } from 'components';
import { useParams } from 'react-router-dom';
import data from 'constants/data.json';

const Option = () => {
  const { menuId, storeId } = useParams();
  const store = data.find((item) => item.storeId === Number(storeId));
  const menu = store?.menus.find((item) => item.id === Number(menuId));

  if (!menu) return null;
  
  return <MenuOption {...menu} />;
};

export default Option;
